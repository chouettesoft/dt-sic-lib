# DTIX-A Reference Prototype Experiment

## Purpose

This package contains a clean, documented version of the executable reference
prototype used for the DTIX-A experiment.

The prototype demonstrates how a Digital Twin information exchange can be:

1. represented as JSON-LD;
2. parsed into an RDF graph using RDFLib; and
3. evaluated against explicit Semantic Information Contract (SIC) rules.

## Important scope

This experiment is **not a generic SHACL benchmark**.

The implementation uses:

- **RDFLib** for JSON-LD parsing and RDF graph construction; and
- **explicit Python logic** for the DTIX-A reference SIC validator.

Therefore, the benchmark measures the implemented prototype, not the general
performance of SHACL engines or all semantic technologies.

---

## Installation

The only required external Python package is RDFLib:

```bash
pip install rdflib
```

Python 3.9 or newer is recommended.

---

## Running the experiment

```bash
python dtix_a_reference_experiment.py
```

The program prints a JSON report containing both experiments.

---

# Experiment 1: Payload scalability

### Question

How does end-to-end processing time change as the exchanged JSON-LD payload
becomes larger?

### Timed path

```text
JSON-LD payload
      |
      v
RDFLib JSON-LD parser
      |
      v
RDF graph
      |
      v
DTIX-A SIC validation
```

### Payload contents

Each payload represents a computed predictive-maintenance result and contains:

- `asset_id`
- `information_type`
- `rul_hours`
- `confidence`
- `model_id`
- `model_version`
- `latency_ms`
- `diagnostic_history`

The `diagnostic_history` list is expanded to create larger serialized payloads.

### Metrics

For each payload size, the script reports:

- actual serialized size in bytes;
- mean latency;
- median latency;
- P95 latency; and
- approximate throughput per second.

---

# Experiment 2: Contract complexity

### Question

How does validation cost change as the number of contract checks increases?

### Design

The JSON-LD payload is parsed into an RDF graph **once** before the timed loop.
The benchmark then repeatedly executes the SIC validator.

This isolates validation cost from repeated JSON-LD parsing.

### Core contract rules

The reference SIC checks:

1. an asset identifier exists;
2. the information type is `computed`;
3. remaining useful life is greater than zero;
4. confidence is at least `0.80`;
5. a model identifier exists;
6. a model version exists; and
7. latency is no greater than `50 ms`.

### Additional controlled rules

The complexity experiment adds `rule_0`, `rule_1`, and so on. Each additional
rule checks that the corresponding RDF property exists and has the expected
value.

These additional rules are a **controlled complexity mechanism**. They should
not be interpreted as a complete model of every possible real-world semantic
constraint.

---

# Interpretation of results

The experiment supports the following limited claim:

> An information-centric Digital Twin transaction can be represented as JSON-LD,
> transformed into an RDF graph, and evaluated against explicit transaction-level
> Semantic Information Contract rules.

The experiment can also show how the cost of this particular implementation
changes with:

- larger payloads; and
- more contract checks.

The results should **not** be generalized directly to:

- all SHACL engines;
- all RDF stores;
- all Digital Twin platforms;
- production hardware; or
- arbitrary semantic reasoning workloads.

---

# Reproducibility notes

For a paper, record the following when executing the experiment:

- Python version;
- RDFLib version;
- operating system;
- CPU model;
- available memory;
- exact command used;
- date/time of execution.

The benchmark results may vary across machines because parsing and validation
performance depend on the execution environment.
