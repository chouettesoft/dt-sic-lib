#!/usr/bin/env python3
"""
DTIX-A Reference Prototype Benchmark
====================================

Purpose
-------
This script provides a small, reproducible reference prototype for evaluating
DTIX-A-style Semantic Information Contract (SIC) validation over JSON-LD data.

The prototype performs two experiments:

1. Payload scalability experiment
   JSON-LD payload -> RDFLib parser -> RDF graph -> SIC validation

   This measures the end-to-end processing time as the serialized payload grows.

2. Contract complexity experiment
   JSON-LD payload -> RDF graph (parsed once) -> repeated SIC validation

   This isolates the cost of validation as the number of contract rules grows.

Scope
-----
This is an executable DTIX-A reference prototype. It is not a generic SHACL
benchmark and does not use a SHACL engine. JSON-LD is parsed with RDFLib and
the SIC rules are implemented explicitly in Python.

Requirements
------------
    pip install rdflib

Run
---
    python dtix_a_reference_experiment.py

The script prints a JSON report and can be used as a clear starting point for
future extensions.
"""

from __future__ import annotations

import json
import math
import statistics
import time
from typing import Any, Dict, List

from rdflib import Graph, Namespace, RDF


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

EX = Namespace("https://example.org/dtix#")

PAYLOAD_EXPERIMENTS = [
    # target size, warm-up iterations, measured iterations
    (150, 3, 10),
    (5_000, 2, 5),
    (10_000, 2, 5),
    (50_000, 2, 5),
    (100_000, 2, 5),
]

COMPLEXITY_EXPERIMENTS = [0, 10, 50, 100, 200]
COMPLEXITY_WARMUP_ITERATIONS = 100
COMPLEXITY_MEASURED_ITERATIONS = 5_000


# ---------------------------------------------------------------------------
# JSON-LD context
# ---------------------------------------------------------------------------

CONTEXT = {
    "@vocab": str(EX),
    "asset_id": {
        "@id": str(EX.asset_id),
        "@type": "http://www.w3.org/2001/XMLSchema#string",
    },
    "information_type": {
        "@id": str(EX.information_type),
    },
    "rul_hours": {
        "@id": str(EX.rul_hours),
        "@type": "http://www.w3.org/2001/XMLSchema#decimal",
    },
    "confidence": {
        "@id": str(EX.confidence),
        "@type": "http://www.w3.org/2001/XMLSchema#decimal",
    },
    "model_id": {
        "@id": str(EX.model_id),
        "@type": "http://www.w3.org/2001/XMLSchema#string",
    },
    "model_version": {
        "@id": str(EX.model_version),
        "@type": "http://www.w3.org/2001/XMLSchema#string",
    },
    "latency_ms": {
        "@id": str(EX.latency_ms),
        "@type": "http://www.w3.org/2001/XMLSchema#decimal",
    },
}


# ---------------------------------------------------------------------------
# Payload generation
# ---------------------------------------------------------------------------

def build_payload(target_bytes: int, extra_rules: int = 0) -> str:
    """
    Create a JSON-LD payload of approximately ``target_bytes``.

    The core payload represents a computed predictive-maintenance result.
    Diagnostic history records are appended until the serialized JSON payload
    reaches the requested size.

    For the contract-complexity experiment, additional properties named
    ``rule_0`` through ``rule_n`` are added. These properties provide a
    controlled way to increase the number of checks performed by the
    reference validator.

    Parameters
    ----------
    target_bytes:
        Approximate minimum serialized payload size in bytes.
    extra_rules:
        Number of additional controlled contract rules to include.

    Returns
    -------
    str
        Serialized JSON-LD payload.
    """
    context = dict(CONTEXT)

    payload: Dict[str, Any] = {
        "@context": context,
        "@id": "https://example.org/dtix#payload-1",
        "@type": "Payload",
        "asset_id": "ARM-ROBOT-892",
        "information_type": "computed",
        "rul_hours": 12.5,
        "confidence": 0.87,
        "model_id": "RUL-Transformer",
        "model_version": "2.1",
        "latency_ms": 12.4,
        "diagnostic_history": [],
    }

    # Add controlled properties used only by the contract-complexity experiment.
    for index in range(extra_rules):
        rule_name = f"rule_{index}"
        context[rule_name] = {
            "@id": str(EX[rule_name]),
            "@type": "http://www.w3.org/2001/XMLSchema#integer",
        }
        payload[rule_name] = index

    serialized = json.dumps(payload, separators=(",", ":"))
    sample_index = 0

    while len(serialized.encode("utf-8")) < target_bytes:
        payload["diagnostic_history"].append(
            {
                "sample_id": sample_index,
                "vibration_rms": 2.31,
                "temperature_c": 71.2,
                "health_score": 0.91,
                "timestamp": "2026-08-25T12:00:00Z",
            }
        )
        sample_index += 1
        serialized = json.dumps(payload, separators=(",", ":"))

    return serialized


# ---------------------------------------------------------------------------
# SIC validation
# ---------------------------------------------------------------------------

def get_payload_subject(graph: Graph):
    """
    Return the RDF subject representing the DTIX-A payload.

    Raises
    ------
    StopIteration
        If no subject of type ``dtix:Payload`` exists.
    """
    return next(graph.subjects(RDF.type, EX.Payload))


def get_first_value(graph: Graph, subject, predicate):
    """Return the first RDF value for a predicate, or ``None`` if absent."""
    return next(graph.objects(subject, predicate), None)


def validate_sic(graph: Graph, extra_rules: int = 0) -> bool:
    """
    Evaluate the DTIX-A reference Semantic Information Contract.

    Core contract requirements
    --------------------------
    1. asset_id must exist.
    2. information_type must be ``computed``.
    3. rul_hours must be greater than zero.
    4. confidence must be at least 0.80.
    5. model_id must exist.
    6. model_version must exist.
    7. latency_ms must not exceed 50 ms.

    Additional controlled rules
    ---------------------------
    When ``extra_rules`` is greater than zero, the validator also checks that
    each generated ``rule_i`` property exists and has the expected integer
    value. These checks are used only to create controlled contract-complexity
    configurations.

    Returns
    -------
    bool
        ``True`` when all applicable contract rules pass; otherwise ``False``.
    """
    subject = get_payload_subject(graph)

    core_checks = [
        bool(get_first_value(graph, subject, EX.asset_id)),
        str(get_first_value(graph, subject, EX.information_type)) == "computed",
        float(get_first_value(graph, subject, EX.rul_hours)) > 0,
        float(get_first_value(graph, subject, EX.confidence)) >= 0.80,
        bool(get_first_value(graph, subject, EX.model_id)),
        bool(get_first_value(graph, subject, EX.model_version)),
        float(get_first_value(graph, subject, EX.latency_ms)) <= 50,
    ]

    if not all(core_checks):
        return False

    for index in range(extra_rules):
        predicate = EX[f"rule_{index}"]
        value = get_first_value(graph, subject, predicate)

        if value is None or int(value) != index:
            return False

    return True


# ---------------------------------------------------------------------------
# Measurement utilities
# ---------------------------------------------------------------------------

def summarize_samples(samples_ms: List[float]) -> Dict[str, float]:
    """
    Calculate descriptive statistics for latency samples.

    The P95 is selected from the sorted sample set using the nearest-rank
    approach, matching the behavior of the original experiment.
    """
    ordered = sorted(samples_ms)
    count = len(ordered)

    mean_ms = statistics.mean(ordered)

    return {
        "mean_ms": mean_ms,
        "median_ms": statistics.median(ordered),
        "p95_ms": ordered[math.ceil(0.95 * count) - 1],
        "throughput_per_s": 1000.0 / mean_ms,
    }


# ---------------------------------------------------------------------------
# Experiment 1: end-to-end payload scalability
# ---------------------------------------------------------------------------

def run_payload_experiment(
    target_bytes: int,
    warmup_iterations: int,
    measured_iterations: int,
) -> Dict[str, float]:
    """
    Measure end-to-end JSON-LD parsing and SIC validation.

    Timed path:
        serialized JSON-LD
            -> RDFLib JSON-LD parsing
            -> RDF graph
            -> SIC validation
    """
    payload = build_payload(target_bytes)

    # Warm-up: perform the same operation without recording measurements.
    for _ in range(warmup_iterations):
        graph = Graph().parse(data=payload, format="json-ld")
        assert validate_sic(graph), "Warm-up payload did not satisfy the SIC."

    samples_ms: List[float] = []

    for _ in range(measured_iterations):
        start_ns = time.perf_counter_ns()

        graph = Graph().parse(data=payload, format="json-ld")
        assert validate_sic(graph), "Measured payload did not satisfy the SIC."

        elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
        samples_ms.append(elapsed_ms)

    return {
        "target_bytes": target_bytes,
        "actual_bytes": len(payload.encode("utf-8")),
        "warmup_iterations": warmup_iterations,
        "measured_iterations": measured_iterations,
        **summarize_samples(samples_ms),
    }


# ---------------------------------------------------------------------------
# Experiment 2: validation-only contract complexity
# ---------------------------------------------------------------------------

def run_contract_complexity_experiment(
    extra_rules: int,
    warmup_iterations: int = COMPLEXITY_WARMUP_ITERATIONS,
    measured_iterations: int = COMPLEXITY_MEASURED_ITERATIONS,
) -> Dict[str, float]:
    """
    Measure SIC validation cost as the number of contract checks increases.

    The JSON-LD payload is parsed once before measurement. Therefore, this
    experiment intentionally measures validation only and excludes repeated
    JSON-LD parsing.
    """
    payload = build_payload(target_bytes=5_000, extra_rules=extra_rules)
    graph = Graph().parse(data=payload, format="json-ld")

    # Warm-up validation.
    for _ in range(warmup_iterations):
        assert validate_sic(graph, extra_rules), (
            "Warm-up graph did not satisfy the SIC."
        )

    samples_ms: List[float] = []

    for _ in range(measured_iterations):
        start_ns = time.perf_counter_ns()

        assert validate_sic(graph, extra_rules), (
            "Measured graph did not satisfy the SIC."
        )

        elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
        samples_ms.append(elapsed_ms)

    return {
        "extra_rules": extra_rules,
        "total_contract_rules": 7 + extra_rules,
        "actual_bytes": len(payload.encode("utf-8")),
        "warmup_iterations": warmup_iterations,
        "measured_iterations": measured_iterations,
        **summarize_samples(samples_ms),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Run both experiments and print a reproducible JSON report."""
    payload_results = [
        run_payload_experiment(
            target_bytes=size,
            warmup_iterations=warmup,
            measured_iterations=measured,
        )
        for size, warmup, measured in PAYLOAD_EXPERIMENTS
    ]

    complexity_results = [
        run_contract_complexity_experiment(extra_rules=extra_rules)
        for extra_rules in COMPLEXITY_EXPERIMENTS
    ]

    report = {
        "experiment": "DTIX-A Reference Prototype Benchmark",
        "scope": (
            "RDFLib JSON-LD parsing plus explicit DTIX-A Semantic Information "
            "Contract validation. Not a generic SHACL-engine benchmark."
        ),
        "payload_experiment": payload_results,
        "contract_complexity_experiment": complexity_results,
    }

    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
